package com.elad.zmanim

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import com.kosherjava.zmanim.hebrewcalendar.HebrewDateFormatter
import com.kosherjava.zmanim.hebrewcalendar.JewishCalendar
import java.util.Calendar
import java.util.GregorianCalendar

/* =========================
   Tuning knobs (easy tweaks)
   ========================= */
object UiTuning {
    val GridGapDp = 6.dp * 0.80f // compact rhythm
    val TodayBg = Color(0xFF8EC3FF)
    val ShabbatBg = Color(0xFFE8F1FF)
    val HolidayChip = Color(0xFF6A1B9A)
    val HeaderPurple = Color(0xFF6A1B9A)
    val ShabbatPurple = Color(0xFF4A148C)
}

data class DayRowUi(
    val localDate: LocalDate,
    val hebrewDayName: String,
    val hebDayOfMonthHeb: String,
    val gregDayAbbrev: String,
    val gregDayOfMonth: String,
    val sunrise: String?,
    val sunset: String?,
    val parasha: String?,
    val holiday: String?,
    val isShabbat: Boolean,
    val isToday: Boolean
)

private val HHMM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val GREG_DAY_ABBR: DateTimeFormatter = DateTimeFormatter.ofPattern("E", Locale.ENGLISH)
private val GREG_DAY_NUM: DateTimeFormatter = DateTimeFormatter.ofPattern("d")

private val SECTION_GAP = 10.dp
private val SECTION_PAD_H = 10.dp

@Composable
fun WeeklyCalendarScreen(
    baseDate: LocalDate,
    city: City,
    tz: ZoneId,
    board: BoardPreset,
    candleOffsetMinutes: Int?,
    modifier: Modifier = Modifier,
    onCityClick: () -> Unit = {}
) {
    val candleOffset = candleOffsetMinutes ?: city.defaultCandleOffsetMin
    val today = remember(tz) { LocalDate.now(tz) }

    val week: List<DayRowUi> = remember(baseDate, city, tz) {
        (0..6).map { plus ->
            val d = baseDate.plusDays(plus.toLong())
            val z = ZmanimProvider.computeAll(d, city.lat, city.lon, tz, city.elevationMeters)
            DayRowUi(
                localDate = d,
                hebrewDayName = hebDayNameShort(d),
                hebDayOfMonthHeb = hebDayOfMonthHeb(d),
                gregDayAbbrev = d.format(GREG_DAY_ABBR) + ".",
                gregDayOfMonth = d.format(GREG_DAY_NUM),
                sunrise = z.sunriseSeaLevel?.format(HHMM),
                sunset = z.sunsetSeaLevel?.format(HHMM),
                parasha = parashaFor(d),
                holiday = holidayFor(d),
                isShabbat = d.dayOfWeek == DayOfWeek.SATURDAY,
                isToday = d == today
            )
        }
    }

    val (gregTop, gregBottom) = remember(week) { gregSpanSplit(week.first().localDate, week.last().localDate) }
    val (hebTop, hebBottom) = remember(baseDate) { hebMonthYearSplit(baseDate) }

    val shabbatDate = remember(baseDate) { nextShabbat(baseDate) }
    val shabbatZ = remember(shabbatDate, city, tz) {
        ZmanimProvider.computeAll(shabbatDate, city.lat, city.lon, tz, city.elevationMeters)
    }

    val bgGrad = Brush.verticalGradient(listOf(Color(0xFFF7F9FD), Color(0xFFF2F5FB)))

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(bgGrad)
                .padding(horizontal = 6.dp, vertical = 2.dp)
                .verticalScroll(rememberScrollState())
        ) {
            HeaderAndTable(
                hebTop = hebTop,
                hebBottom = hebBottom,
                cityName = city.display,
                gregTop = gregTop,
                gregBottom = gregBottom,
                week = week,
                onCityClick = onCityClick
            )

            Spacer(Modifier.height(SECTION_GAP))

            ShabbatSummaryRow(
                candle = shabbatZ.sunsetSeaLevel?.minusMinutes((18 + candleOffset).toLong())?.format(HHMM),
                havdalah = shabbatZ.tzeitStandard?.format(HHMM)
            )

            Spacer(Modifier.height(SECTION_GAP))
            Divider(color = Color(0xFFE3E7EF))
            Spacer(Modifier.height(SECTION_GAP))

            Row(
                Modifier.fillMaxWidth().padding(horizontal = SECTION_PAD_H),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "זמני היום",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
            }

            Spacer(Modifier.height(UiTuning.GridGapDp))

            PrayerTimesList(anchor = week.first(), city = city, tz = tz, board = board)
        }
    }
}

/** Combined header + weekly table; Hebrew cell stacked; Gregorian cell stacked; sunrise icon only in header. */
@Composable
private fun HeaderAndTable(
    hebTop: String,
    hebBottom: String,
    cityName: String,
    gregTop: String,
    gregBottom: String,
    week: List<DayRowUi>,
    onCityClick: () -> Unit
) {
    val uri = LocalUriHandler.current

    Surface(
        shape = RoundedCornerShape(10.dp),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White)
        ) {
            // Force LTR so left/right are physical
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = SECTION_PAD_H, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val labelSmall10 = MaterialTheme.typography.labelSmall.copy(
                        fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * 1.10f).sp,
                        fontWeight = FontWeight.SemiBold,
                        color = UiTuning.HeaderPurple,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )
                    // Left: Gregorian month/top + year/bottom
                    Column(horizontalAlignment = Alignment.Start) {
                        Text(gregTop, style = labelSmall10)
                        Text(gregBottom, style = labelSmall10)
                    }
                    // Center: city (bigger)
                    Text(
                        cityName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            platformStyle = PlatformTextStyle(includeFontPadding = false)
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.clickable { onCityClick() }
                    )
                    // Right: Hebrew month/top + Hebrew year/bottom
                    Column(horizontalAlignment = Alignment.End) {
                        Text(hebTop, style = labelSmall10)
                        Text(hebBottom, style = labelSmall10)
                    }
                }
            }

            // Icon header (sunset left, sunrise right) — keep icons tiny and aligned to time columns
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 0.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(Modifier.weight(1.1f).fillMaxWidth()) {
                        Box(Modifier.weight(1f)) // stacked greg column
                        Box(Modifier.weight(1f)) // sunset time column
                        Box(Modifier.weight(0f)) {} // no third column on left now
                        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                            Icon(
                                Icons.Filled.DarkMode,
                                contentDescription = "Sunset",
                                tint = Color(0xFF37474F),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Box(Modifier.weight(1.05f).height(16.dp)) {
                        Divider(
                            color = Color(0xFFDDDDDD),
                            modifier = Modifier
                                .width(1.dp)
                                .fillMaxHeight()
                                .align(Alignment.Center)
                        )
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(Modifier.weight(0.85f).fillMaxWidth()) {
                            Box(Modifier.weight(1f)) // stacked heb column
                            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                                Icon(
                                    Icons.Filled.LightMode,
                                    contentDescription = "Sunrise",
                                    tint = Color(0xFFF9A825),
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .size(14.dp)
                                )
                            }
                        }
                    }
                }
            }

            Divider(color = Color(0xFFE3E7EF))

            // Body rows
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                week.forEach { d ->
                    val rowBg = when {
                        d.isToday -> UiTuning.TodayBg
                        d.isShabbat -> UiTuning.ShabbatBg
                        else -> Color.White
                    }

                    val base = MaterialTheme.typography.bodyLarge
                    val gregTopStyle = base.copy( // greg day-of-month top
                        fontWeight = FontWeight.SemiBold,
                        fontSize = (base.fontSize.value * 0.90f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )
                    val gregBottomStyle = MaterialTheme.typography.labelSmall.copy( // greg abbr bottom
                        fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * 0.90f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )
                    val hebTopStyle = base.copy( // heb day-of-month top (bigger than name)
                        fontWeight = FontWeight.SemiBold,
                        fontSize = (base.fontSize.value * 0.75f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )
                    val hebBottomStyle = base.copy( // heb day-name bottom (smaller, tight)
                        fontWeight = FontWeight.Medium,
                        fontSize = (base.fontSize.value * 0.58f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )
                    val timeStyle = MaterialTheme.typography.labelSmall.copy(
                        fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * 0.90f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false),
                        fontFeatureSettings = "tnum"
                    )
                    val holidayStyle = hebBottomStyle

                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // LEFT — Gregorian STACKED (day↑ over abbr↓) + sunset time
                        Row(
                            Modifier.weight(1.05f).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // stacked greg
                            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text(d.gregDayOfMonth, style = gregTopStyle)
                                    Text(d.gregDayAbbrev, style = gregBottomStyle)
                                }
                            }
                            // sunset time
                            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                Text(d.sunset ?: "--", style = timeStyle)
                            }
                        }

                        // MIDDLE — divider + Holiday/Parasha (more room)
                        Box(
                            modifier = Modifier
                                .weight(1.15f)
                                .height(IntrinsicSize.Min)
                        ) {
                            Divider(
                                color = Color(0xFFDDDDDD),
                                modifier = Modifier
                                    .width(1.dp)
                                    .fillMaxHeight()
                                    .align(Alignment.Center)
                            )

                            when {
                                !d.holiday.isNullOrBlank() -> {
                                    Surface(
                                        color = UiTuning.HolidayChip.copy(alpha = 0.10f),
                                        contentColor = UiTuning.HolidayChip,
                                        shape = RoundedCornerShape(12.dp),
                                        tonalElevation = 0.dp,
                                        shadowElevation = 0.dp,
                                        modifier = Modifier.align(Alignment.Center)
                                    ) {
                                        Text(
                                            d.holiday!!,
                                            style = holidayStyle,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                d.isShabbat && !d.parasha.isNullOrBlank() -> {
                                    val q = "פרשת השבוע ${d.parasha}"
                                    val url = "https://www.youtube.com/results?search_query=" +
                                            URLEncoder.encode(q, StandardCharsets.UTF_8.toString())
                                    Text(
                                        d.parasha!!,
                                        style = holidayStyle,
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .padding(horizontal = 2.dp)
                                            .clickable { uri.openUri(url) }
                                    )
                                }
                            }
                        }

                        // RIGHT — Hebrew STACKED (day↑ over name↓) + sunrise time (no icon here)
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Row(
                                Modifier.weight(0.80f).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // stacked hebrew (tighter)
                                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                                    Column(
                                        horizontalAlignment = Alignment.End,
                                        verticalArrangement = Arrangement.spacedBy(0.dp)
                                    ) {
                                        Text(d.hebDayOfMonthHeb, style = hebTopStyle)
                                        Text(d.hebrewDayName, style = hebBottomStyle)
                                    }
                                }
                                // sunrise time (text only; icon stays in header)
                                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                                    Text(d.sunrise ?: "--", style = timeStyle, color = Color(0xFF444444))
                                }
                            }
                        }
                    }
                    Divider(color = Color(0xFFE3E7EF))
                }
            }
        }
    }
}

/** Shabbat summary (bigger): LEFT = havdalah, RIGHT = candle. */
@Composable
private fun ShabbatSummaryRow(candle: String?, havdalah: String?) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = SECTION_PAD_H),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SummaryBox(
                title = "צאת שבת",
                value = havdalah ?: "--",
                bg = UiTuning.ShabbatPurple.copy(alpha = 0.16f),
                contentColor = UiTuning.ShabbatPurple,
                modifier = Modifier.weight(1f)
            )
            SummaryBox(
                title = "כניסת שבת",
                value = candle ?: "--",
                bg = UiTuning.ShabbatPurple.copy(alpha = 0.16f),
                contentColor = UiTuning.ShabbatPurple,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SummaryBox(
    title: String,
    value: String,
    bg: Color,
    contentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.heightIn(min = 64.dp), // taller
        shape = RoundedCornerShape(12.dp),
        color = bg,
        contentColor = contentColor,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(
            Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold))
            Spacer(Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold))
        }
    }
}

/** Prayer times — clean list (no boxes). Label = right, time = left (flush). */
@Composable
private fun PrayerTimesList(anchor: DayRowUi, city: City, tz: ZoneId, board: BoardPreset) {
    val z = ZmanimProvider.computeAll(anchor.localDate, city.lat, city.lon, tz, city.elevationMeters)
    val isMGA = board == BoardPreset.MGA
    val isGRA = board == BoardPreset.GRA

    @Composable
    fun RowItem(label: String, time: LocalTime?, emphasize: Boolean = false) {
        val t = time?.format(HHMM) ?: "--"
        val style = if (emphasize)
            MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
        else
            MaterialTheme.typography.labelSmall

        // Force LTR so physical left/right are consistent
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp, horizontal = SECTION_PAD_H),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: time
                Text(
                    t,
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.weight(1f)
                )
                // Right: label
                Text(
                    label,
                    style = style,
                    textAlign = TextAlign.End,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Divider(color = Color(0xFFE6E9F0))
    }

    Column(Modifier.fillMaxWidth()) {
        RowItem("עלות השחר", z.alosHashachar)
        RowItem("זריחה", z.sunriseSeaLevel)
        RowItem("טלית ותפילין", z.misheyakir11_5)
        RowItem("חצות היום", z.chatzot)
        RowItem("מנחה גדולה", z.minchaGedola)
        RowItem("מנחה קטנה", z.minchaKetana)
        RowItem("פלג המנחה", z.plagHamincha)
        RowItem("שקיעה", z.sunsetSeaLevel)
        RowItem("צאת הכוכבים", z.tzeitStandard)
        RowItem("סו\"ז ק\"ש מג\"א", z.sofZmanShmaMGA, emphasize = isMGA)
        RowItem("סו\"ז ק\"ש גרא", z.sofZmanShmaGRA, emphasize = isGRA)
        RowItem("סו\"ז תפילה מג\"א", z.sofZmanTfilaMGA, emphasize = isMGA)
        RowItem("סו\"ז תפילה גרא", z.sofZmanTfilaGRA, emphasize = isGRA)
    }
}

/* ===== helpers ===== */

private fun hebDayNameShort(d: LocalDate): String = when (d.dayOfWeek) {
    DayOfWeek.SUNDAY -> "ראשון"
    DayOfWeek.MONDAY -> "שני"
    DayOfWeek.TUESDAY -> "שלישי"
    DayOfWeek.WEDNESDAY -> "רביעי"
    DayOfWeek.THURSDAY -> "חמישי"
    DayOfWeek.FRIDAY -> "שישי"
    DayOfWeek.SATURDAY -> "שבת"
}

private fun hebMonthYearSplit(d: LocalDate, inIsrael: Boolean = true): Pair<String,String> {
    val parts = hebrewDateFor(d, inIsrael).trim().split(' ')
    val last2 = parts.takeLast(2)
    val month = last2.getOrNull(0) ?: ""
    val year = last2.getOrNull(1) ?: ""
    return month to year
}

/** Returns (top, bottom) where top is month or month-span, bottom is year or year-span. */
private fun gregSpanSplit(start: LocalDate, end: LocalDate): Pair<String,String> {
    val monthFmt = DateTimeFormatter.ofPattern("MMMM", Locale.ENGLISH)
    val yearFmt = DateTimeFormatter.ofPattern("yyyy", Locale.ENGLISH)
    val m1 = start.format(monthFmt)
    val y1 = start.format(yearFmt)
    val m2 = end.format(monthFmt)
    val y2 = end.format(yearFmt)
    val top = if (m1 == m2) m1 else "$m1–$m2"
    val bottom = if (y1 == y2) y1 else "$y1–$y2"
    return top to bottom
}

private fun hebrewMonthYear(d: LocalDate): String =
    hebrewDateFor(d, inIsrael = true).split(' ').takeLast(2).joinToString(" ")

private fun gregorianMonthSpan(start: LocalDate, end: LocalDate): String {
    val fmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)
    val a = start.withDayOfMonth(1).format(fmt)
    val b = end.withDayOfMonth(1).format(fmt)
    return if (a == b) a else "$a – $b"
}

private fun hebDayOfMonthHeb(date: LocalDate, inIsrael: Boolean = true): String {
    val cal: Calendar = GregorianCalendar().apply {
        set(Calendar.YEAR, date.year)
        set(Calendar.MONTH, date.monthValue - 1)
        set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.formatHebrewNumber(jc.jewishDayOfMonth)
}

/** Holiday name (Hebrew) or null if not a holiday. */
private fun holidayFor(date: LocalDate, inIsrael: Boolean = true): String? {
    val cal: Calendar = GregorianCalendar().apply {
        set(Calendar.YEAR, date.year)
        set(Calendar.MONTH, date.monthValue - 1)
        set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
        set(Calendar.HOUR_OF_DAY, 12)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    val name = fmt.formatYomTov(jc) ?: return null
    return if (name.isBlank()) null else name
}

/** Parasha for a specific Gregorian date (Hebrew name if Shabbat; else null). */
private fun parashaFor(date: LocalDate, inIsrael: Boolean = true): String? {
    if (date.dayOfWeek != DayOfWeek.SATURDAY) return null
    val cal: Calendar = GregorianCalendar().apply {
        set(Calendar.YEAR, date.year)
        set(Calendar.MONTH, date.monthValue - 1)
        set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
        set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    val name = fmt.formatParsha(jc) ?: return null
    return if (name.isBlank()) null else name
}
