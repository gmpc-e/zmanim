package com.elad.zmanim

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import com.elad.zmanim.boards.*
import com.elad.zmanim.boards.BoardProfile
import com.elad.zmanim.selectByProfile
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.*
import com.kosherjava.zmanim.hebrewcalendar.HebrewDateFormatter
import com.kosherjava.zmanim.hebrewcalendar.JewishCalendar

/* ===== models for the weekly UI ===== */

data class DayRowUi(
    val localDate: LocalDate,
    val hebrewDayName: String,
    val hebDayOfMonthHeb: String,
    val gregDayAbbrev: String,
    val gregDayOfMonth: String,
    val sunrise: String?,
    val sunset: String?,
    val parasha: String?,
    val holiday: String?,
    val isShabbat: Boolean,
    val isToday: Boolean
)

/* ===== formatters ===== */

private val HHMM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val GREG_DAY_ABBR: DateTimeFormatter = DateTimeFormatter.ofPattern("E", Locale.ENGLISH)
private val GREG_DAY_NUM: DateTimeFormatter = DateTimeFormatter.ofPattern("d")

/* ===== theme tweaks used here ===== */

private object UiTuning {
    val SectionPadH = 12.dp
    val SectionPadV = 10.dp
    val HolidayChip = Color(0xFF6A5ACD)
    val ShabbatPurple = Color(0xFF5B3BAE)
    val TodayBg = Color(0xFFD9ECFF)
    val ShabbatBg = Color(0xFFF1EAFE)
}

/* ===== main screen ===== */

@Composable
fun WeeklyCalendarScreen(
    baseDate: LocalDate,
    city: City,
    tz: ZoneId,
    board: BoardPreset,
    candleOffsetMinutes: Int?,
    modifier: Modifier = Modifier,
    onCityClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val candleOffset = candleOffsetMinutes ?: city.defaultCandleOffsetMin
    val today = remember(tz) { LocalDate.now(tz) }

    // Load hilulot list once
    val hilulot = remember { loadHilulot(context) }

    val week: List<DayRowUi> = remember(baseDate, city, tz) {
        (0..6).map { plus ->
            val d = baseDate.plusDays(plus.toLong())
            val z = ZmanimProvider.computeAll(d, city.lat, city.lon, tz, city.elevationMeters)
            DayRowUi(
                localDate = d,
                hebrewDayName = hebDayNameShort(d),
                hebDayOfMonthHeb = hebDayOfMonthHeb(d),
                gregDayAbbrev = d.format(GREG_DAY_ABBR) + ".",
                gregDayOfMonth = d.format(GREG_DAY_NUM),
                sunrise = z.sunriseSeaLevel?.format(HHMM),
                sunset = z.sunsetSeaLevel?.format(HHMM),
                parasha = parashaFor(d),
                holiday = holidayFor(d),
                isShabbat = d.dayOfWeek == DayOfWeek.SATURDAY,
                isToday = d == today
            )
        }
    }

    val (gregTop, gregBottom) = remember(week) { gregSpanSplit(week.first().localDate, week.last().localDate) }
    val (hebTop, hebBottom)   = remember(baseDate) { hebMonthYearSplit(baseDate) }

    val shabbatDate = remember(baseDate) { nextShabbatFrom(baseDate) }
    val shabbatZ: ZmanResults = remember(shabbatDate, city, tz) {
        ZmanimProvider.computeAll(shabbatDate, city.lat, city.lon, tz, city.elevationMeters)
    }

    // Candle lighting = Friday sunset - candleOffset
    val erevShabbat = remember(shabbatDate) { shabbatDate.minusDays(1) }
    val erevZ: ZmanResults = remember(erevShabbat, city, tz) {
        ZmanimProvider.computeAll(erevShabbat, city.lat, city.lon, tz, city.elevationMeters)
    }
    val candleText = erevZ.sunsetSeaLevel
        ?.minusMinutes(candleOffset.toLong())
        ?.format(HHMM)
        ?.let { "$it (${candleOffset}-)" }

    val bgGrad = Brush.verticalGradient(listOf(Color(0xFFF7F9FD), Color(0xFFF2F5FB)))

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier
                .background(bgGrad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = UiTuning.SectionPadH, vertical = UiTuning.SectionPadV)
                .fillMaxSize()
        ) {
            /* ===== header (months/years + city) ===== */
            HeaderRow(
                gregTop = gregTop, gregBottom = gregBottom,
                hebTop = hebTop, hebBottom = hebBottom,
                cityLabel = city.toString(),
                onCityClick = onCityClick
            )

            Spacer(Modifier.height(8.dp))

            /* ===== table (7 rows) ===== */
            week.forEach { d ->
                DayRow(d = d, city = city, tz = tz, board = board, hilulot = hilulot)
                Divider(color = Color(0xFFE3E7EF))
            }

            /* ===== Shabbat summary cards ===== */
            ShabbatSummaryRow(
                candle = candleText,
                havdalah = shabbatZ.tzeitRT72?.format(HHMM) ?: shabbatZ.tzeitStandard?.format(HHMM)
            )

            Spacer(Modifier.height(12.dp))

            /* ===== Prayer times list (board-aware) ===== */
            PrayerTimesList(anchor = week.first(), city = city, tz = tz, board = board)
        }
    }
}

/* ===== header composable ===== */

@Composable
private fun HeaderRow(
    gregTop: String, gregBottom: String,
    hebTop: String, hebBottom: String,
    cityLabel: String,
    onCityClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(gregTop, color = Color(0xFF6A5ACD), fontWeight = FontWeight.SemiBold)
            Text(gregBottom, color = Color(0xFF6A5ACD), fontWeight = FontWeight.SemiBold)
        }
        Text(
            cityLabel,
            modifier = Modifier.clickable { onCityClick() },
            style = MaterialTheme.typography.titleMedium,
            color = Color(0xFF333333)
        )
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text(hebTop, color = Color(0xFF6A5ACD), fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
            Text(hebBottom, color = Color(0xFF6A5ACD), fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
        }
    }
    Spacer(Modifier.height(6.dp))
}

/* ===== Shabbat summary ===== */

@Composable
private fun ShabbatSummaryRow(candle: String?, havdalah: String?) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = UiTuning.SectionPadH),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SummaryBox("צאת שבת", havdalah ?: "--", UiTuning.ShabbatPurple.copy(alpha = 0.16f), UiTuning.ShabbatPurple, Modifier.weight(1f))
            SummaryBox("כניסת שבת", candle ?: "--", UiTuning.ShabbatPurple.copy(alpha = 0.16f), UiTuning.ShabbatPurple, Modifier.weight(1f))
        }
    }
}

@Composable
private fun SummaryBox(title: String, value: String, bg: Color, contentColor: Color, modifier: Modifier = Modifier) {
    Surface(color = bg, contentColor = contentColor, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold))
        }
    }
}

/* ===== PrayerTimes (board-aware) ===== */

@Composable
private fun PrayerTimesList(anchor: DayRowUi, city: City, tz: ZoneId, board: BoardPreset) {
    val z = ZmanimProvider.computeAll(anchor.localDate, city.lat, city.lon, tz, city.elevationMeters)
    val profile: BoardProfile = BOARD_PROFILES[board] ?: BOARD_PROFILES.getValue(BoardPreset.GRA)
    val sel = selectByProfile(z, profile)

    val isMGA = profile.sofZmanRef == SofZmanRef.MGA
    val isGRA = profile.sofZmanRef == SofZmanRef.GRA
    val isRT  = board == BoardPreset.RABEINU_TAM

    @Composable
    fun RowItem(label: String, time: LocalTime?, emphasize: Boolean = false, infoKey: String? = null) {
        val t = time?.format(HHMM) ?: "--"
        val style = if (emphasize) MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
        else MaterialTheme.typography.labelSmall
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, style = style, modifier = Modifier.weight(1f).wrapContentWidth(Alignment.End), textAlign = TextAlign.End)
                Spacer(Modifier.width(8.dp))
                Text(t, style = if (emphasize) style.copy(fontWeight = FontWeight.Bold) else style)
                if (infoKey != null) {
                    Spacer(Modifier.width(6.dp))
                    InfoIcon(profile.explanations[infoKey])
                }
            }
        }
        Divider(color = Color(0xFFE6E9F0))
    }

    Column(Modifier.fillMaxWidth()) {
        RowItem("עלות השחר", z.alosHashachar, infoKey = "alos")
        RowItem("טלית ותפילין", sel.misheyakir, infoKey = "misheyakir")
        RowItem("זריחה", sel.sunrise, infoKey = "sunrise")
        RowItem("חצות היום", sel.chatzot, infoKey = "chatzot")
        RowItem("מנחה גדולה", sel.minchaGedola, infoKey = "minchaGedola")
        RowItem("מנחה קטנה", sel.minchaKetana, infoKey = "minchaKetana")
        RowItem("פלג המנחה", sel.plag, infoKey = "plag")
        RowItem("שקיעה", sel.sunset, infoKey = "sunset")

        RowItem(if (isRT) "צאת הכוכבים (רבינו תם)" else "צאת הכוכבים", sel.tzeitPrimary, emphasize = isRT, infoKey = "tzeit")
        if (sel.tzeitSecondary != null) {
            val t: LocalTime = sel.tzeitSecondary
            RowItem(if (isRT) "צאת (סטנדרטי)" else "צאת (רבינו תם)", time = t)
        }

        RowItem("סו\"ז ק\"ש מג\"א", sel.sofZmanShmaMga, emphasize = isMGA, infoKey = "sofZmanShma")
        RowItem("סו\"ז ק\"ש גר\"א", sel.sofZmanShmaGra, emphasize = isGRA, infoKey = "sofZmanShma")
        RowItem("סו\"ז תפילה מג\"א", sel.sofZmanTfilaMga, emphasize = isMGA)
        RowItem("סו\"ז תפילה גר\"א", sel.sofZmanTfilaGra, emphasize = isGRA)
    }
}

@Composable
private fun InfoIcon(text: String?) {
    if (text.isNullOrBlank()) return
    var open by remember { mutableStateOf(false) }
    Icon(
        imageVector = Icons.Filled.Info,
        contentDescription = "מידע",
        modifier = Modifier.size(16.dp).clickable { open = true },
        tint = Color(0xFF6A5ACD)
    )
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton(onClick = { open = false }) { Text("סגור") } },
            title = { Text("הסבר קצר") },
            text = { Text(text) }
        )
    }
}

/* ===== helpers ===== */

private fun hebDayNameShort(d: LocalDate): String = when (d.dayOfWeek) {
    DayOfWeek.SUNDAY -> "ראשון"
    DayOfWeek.MONDAY -> "שני"
    DayOfWeek.TUESDAY -> "שלישי"
    DayOfWeek.WEDNESDAY -> "רביעי"
    DayOfWeek.THURSDAY -> "חמישי"
    DayOfWeek.FRIDAY -> "שישי"
    DayOfWeek.SATURDAY -> "שבת"
}

private fun hebDayOfMonthHeb(d: LocalDate, inIsrael: Boolean = true): String {
    val cal: Calendar = GregorianCalendar().apply {
        set(d.year, d.monthValue - 1, d.dayOfMonth, 12, 0, 0)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.formatHebrewNumber(jc.jewishDayOfMonth)
}

private fun hebrewDateForLocal(d: LocalDate, inIsrael: Boolean = true): String {
    val cal: Calendar = GregorianCalendar().apply {
        set(d.year, d.monthValue - 1, d.dayOfMonth, 12, 0, 0)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.format(jc)
}

private fun hebMonthYearSplit(d: LocalDate, inIsrael: Boolean = true): Pair<String, String> {
    val parts = hebrewDateForLocal(d, inIsrael).trim().split(' ')
    val last2 = parts.takeLast(2)
    return (last2.getOrNull(0) ?: "") to (last2.getOrNull(1) ?: "")
}

private fun gregSpanSplit(start: LocalDate, end: LocalDate): Pair<String, String> {
    val monthFmt = DateTimeFormatter.ofPattern("MMMM", Locale.ENGLISH)
    val yearFmt  = DateTimeFormatter.ofPattern("yyyy")
    val sM = start.format(monthFmt)
    val eM = end.format(monthFmt)
    val sY = start.format(yearFmt)
    val eY = end.format(yearFmt)
    val top = if (sM == eM) sM else "$sM–$eM"
    val bottom = if (sY == eY) sY else "$sY–$eY"
    return top to bottom
}

private fun holidayFor(date: LocalDate, inIsrael: Boolean = true): String? {
    val cal: Calendar = GregorianCalendar().apply {
        set(date.year, date.monthValue - 1, date.dayOfMonth, 12, 0, 0)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.formatYomTov(jc)?.takeIf { it.isNotBlank() }
}

private fun parashaFor(date: LocalDate, inIsrael: Boolean = true): String? {
    if (date.dayOfWeek != DayOfWeek.SATURDAY) return null
    val cal: Calendar = GregorianCalendar().apply {
        set(date.year, date.monthValue - 1, date.dayOfMonth, 12, 0, 0)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.formatParsha(jc)?.takeIf { it.isNotBlank() }
}

private fun nextShabbatFrom(from: LocalDate): LocalDate {
    var d = from
    while (d.dayOfWeek != DayOfWeek.SATURDAY) d = d.plusDays(1)
    return d
}
