package com.elad.zmanim.boards

/** Which classic preset/shita the user chose */
enum class BoardPreset { GRA, MGA, RABEINU_TAM, OR_HACHAIM /*, CUSTOM */ }

enum class SolarRef { SeaLevel, Visible }
enum class MisheyakirRef { Angle11_5, Angle10_2, Angle9_5, Angle7_65 }
enum class TzeitRef { StandardAngle, RT72 }
enum class SofZmanRef { GRA, MGA, BOTH }

/** How to derive proportional-day frame; useful later if we compute custom shaot zmaniot */
sealed interface DayRef {
    data class Sunrise(val kind: SolarRef) : DayRef
    data class Sunset(val kind: SolarRef)  : DayRef
    /** Alot/Tzeit by angle below horizon (degrees) or fixed minutes after sunset */
    data class Alot(val angleDeg: Double) : DayRef
    data class TzeitAngle(val angleDeg: Double) : DayRef
    data class TzeitMinutes(val minutes: Int) : DayRef
}

/** Declarative profile for a halachic board */
data class BoardProfile(
    val preset: BoardPreset,
    val dayStart: DayRef,
    val dayEnd: DayRef,
    val sunriseKind: SolarRef = SolarRef.SeaLevel,
    val sunsetKind: SolarRef = SolarRef.SeaLevel,
    val misheyakir: MisheyakirRef = MisheyakirRef.Angle11_5,
    val tzeit: TzeitRef = TzeitRef.StandardAngle,
    /** Which sof zman rows should be PRIMARY */
    val sofZmanRef: SofZmanRef = SofZmanRef.GRA,
    /** Small Hebrew “i” texts per key used in UI (optional; can expand later) */
    val explanations: Map<String, String> = emptyMap()
)

/** Built-in profiles (safe defaults; we can tune angles later). */
val BOARD_PROFILES: Map<BoardPreset, BoardProfile> = mapOf(
    BoardPreset.GRA to BoardProfile(
        preset = BoardPreset.GRA,
        dayStart = DayRef.Sunrise(SolarRef.SeaLevel),
        dayEnd   = DayRef.Sunset(SolarRef.SeaLevel),
        sunriseKind = SolarRef.SeaLevel,
        sunsetKind  = SolarRef.SeaLevel,
        misheyakir = MisheyakirRef.Angle11_5,
        tzeit = TzeitRef.StandardAngle,
        sofZmanRef = SofZmanRef.GRA,
        explanations = mapOf(
            "misheyakir" to "משיכיר ≈ כשהשמש כ־11.5° מתחת לאופק — זמן לתלית ותפילין.",
            "sofZmanShma" to "סו\"ז ק\"ש לפי הגר\"א: שעות זמניות בין זריחה לשקיעה.",
            "tzeit" to "צאת הכוכבים (סטנדרטי): לפי זווית שמש מקובלת."
        )
    ),
    BoardPreset.MGA to BoardProfile(
        preset = BoardPreset.MGA,
        dayStart = DayRef.Alot(angleDeg = 16.1),
        dayEnd   = DayRef.TzeitAngle(angleDeg = 8.5),
        sunriseKind = SolarRef.SeaLevel,
        sunsetKind  = SolarRef.SeaLevel,
        misheyakir = MisheyakirRef.Angle11_5,
        tzeit = TzeitRef.StandardAngle,
        sofZmanRef = SofZmanRef.MGA,
        explanations = mapOf(
            "sofZmanShma" to "סו\"ז ק\"ש לפי מג\"א: שעות זמניות מעלות השחר עד צאת הכוכבים."
        )
    ),
    BoardPreset.RABEINU_TAM to BoardProfile(
        preset = BoardPreset.RABEINU_TAM,
        dayStart = DayRef.Alot(angleDeg = 16.1),
        dayEnd   = DayRef.TzeitMinutes(minutes = 72), // רבינו תם
        sunriseKind = SolarRef.SeaLevel,
        sunsetKind  = SolarRef.SeaLevel,
        misheyakir = MisheyakirRef.Angle11_5,
        tzeit = TzeitRef.RT72,
        sofZmanRef = SofZmanRef.GRA, // ניתן לשינוי לפי מנהג
        explanations = mapOf(
            "tzeit" to "רבינו תם ≈ 72 דקות אחרי שקיעה (מנהגים שונים קיימים)."
        )
    ),
    BoardPreset.OR_HACHAIM to BoardProfile(
        preset = BoardPreset.OR_HACHAIM,
        dayStart = DayRef.Sunrise(SolarRef.Visible),
        dayEnd   = DayRef.Sunset(SolarRef.Visible),
        sunriseKind = SolarRef.Visible,
        sunsetKind  = SolarRef.Visible,
        misheyakir = MisheyakirRef.Angle11_5,
        tzeit = TzeitRef.StandardAngle,
        sofZmanRef = SofZmanRef.GRA
    )
)
