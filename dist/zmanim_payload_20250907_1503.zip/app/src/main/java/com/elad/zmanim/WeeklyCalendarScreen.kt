package com.elad.zmanim

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import com.kosherjava.zmanim.hebrewcalendar.HebrewDateFormatter
import com.kosherjava.zmanim.hebrewcalendar.JewishCalendar
import java.util.Calendar
import java.util.GregorianCalendar

data class DayRowUi(
    val localDate: LocalDate,
    val hebrewDayName: String,
    val hebDayOfMonthHeb: String,
    val gregDayAbbrev: String,
    val gregDayOfMonth: String,
    val sunrise: String?,
    val sunset: String?,
    val parasha: String?,     // ← new: specific parasha (Heb)
    val isShabbat: Boolean,
    val isToday: Boolean      // ← new: highlight current day
)

private val HHMM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val GREG_DAY_ABBR: DateTimeFormatter = DateTimeFormatter.ofPattern("E", Locale.ENGLISH)
private val GREG_DAY_NUM: DateTimeFormatter = DateTimeFormatter.ofPattern("d")

/* Section spacing */
private val SECTION_GAP = 10.dp
private val SECTION_PAD_H = 10.dp

@Composable
fun WeeklyCalendarScreen(
    baseDate: LocalDate,          // pass SUNDAY for weekly view
    city: City,
    tz: ZoneId,
    board: BoardPreset,
    candleOffsetMinutes: Int?,
    modifier: Modifier = Modifier,
    onCityClick: () -> Unit = {}
) {
    val candleOffset = candleOffsetMinutes ?: city.defaultCandleOffsetMin
    val today = remember(tz) { LocalDate.now(tz) }

    val week: List<DayRowUi> = remember(baseDate, city, tz) {
        (0..6).map { plus ->
            val d = baseDate.plusDays(plus.toLong())
            val z = ZmanimProvider.computeAll(d, city.lat, city.lon, tz, city.elevationMeters)
            DayRowUi(
                localDate = d,
                hebrewDayName = hebDayNameShort(d),
                hebDayOfMonthHeb = hebDayOfMonthHeb(d),
                gregDayAbbrev = d.format(GREG_DAY_ABBR) + ".",
                gregDayOfMonth = d.format(GREG_DAY_NUM),
                sunrise = z.sunriseSeaLevel?.format(HHMM),
                sunset = z.sunsetSeaLevel?.format(HHMM),
                parasha = parashaFor(d),                           // ← get specific parasha (if Shabbat)
                isShabbat = d.dayOfWeek == DayOfWeek.SATURDAY,
                isToday = d == today
            )
        }
    }

    val gregSpan = remember(week) { gregorianMonthSpan(week.first().localDate, week.last().localDate) }
    val hebMonthYear = remember(baseDate) { hebrewMonthYear(baseDate) }

    val shabbatDate = remember(baseDate) { nextShabbat(baseDate) }
    val shabbatZ = remember(shabbatDate, city, tz) {
        ZmanimProvider.computeAll(shabbatDate, city.lat, city.lon, tz, city.elevationMeters)
    }

    val bgGrad = Brush.verticalGradient(listOf(Color(0xFFF7F9FD), Color(0xFFF2F5FB)))

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(bgGrad)
                .padding(horizontal = 6.dp, vertical = 2.dp) // a tad tighter up top
                .verticalScroll(rememberScrollState())
        ) {
            HeaderAndTable(
                hebMonthYear = hebMonthYear,
                cityName = city.display,
                gregSpan = gregSpan,
                week = week,
                onCityClick = onCityClick
            )

            Spacer(Modifier.height(SECTION_GAP))

            ShabbatSummaryRow(
                candle = shabbatZ.sunsetSeaLevel?.minusMinutes((18 + candleOffset).toLong())?.format(HHMM),
                havdalah = shabbatZ.tzeitStandard?.format(HHMM)
            )

            Spacer(Modifier.height(SECTION_GAP))
            Divider(color = Color(0xFFE3E7EF))
            Spacer(Modifier.height(SECTION_GAP))

            Row(Modifier.fillMaxWidth().padding(horizontal = SECTION_PAD_H), horizontalArrangement = Arrangement.Center) {
                Text("זמני היום", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
            }

            Spacer(Modifier.height(6.dp))

            PrayerTimesBoxes(anchor = week.first(), city = city, tz = tz, board = board)
        }
    }
}

/** Combined header + weekly table (with icon header row, today highlight, and parasha link on Shabbat). */
@Composable
private fun HeaderAndTable(
    hebMonthYear: String,
    cityName: String,
    gregSpan: String,
    week: List<DayRowUi>,
    onCityClick: () -> Unit
) {
    val uri = LocalUriHandler.current

    Surface(
        shape = RoundedCornerShape(10.dp),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White)
        ) {
            // Header row
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = SECTION_PAD_H, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val labelSmall10 = MaterialTheme.typography.labelSmall.copy(
                    fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * 0.9f).sp,
                    platformStyle = PlatformTextStyle(includeFontPadding = false)
                )
                Text(gregSpan, style = labelSmall10, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                Text(
                    cityName,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.clickable { onCityClick() }
                )
                Text(hebMonthYear, style = labelSmall10)
            }

            // Icon header row (sunset left, sunrise right)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(Modifier.weight(1.2f).fillMaxWidth()) {
                        Box(Modifier.weight(1f))
                        Box(Modifier.weight(1f))
                        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                            Icon(Icons.Filled.DarkMode, contentDescription = "Sunset", tint = Color(0xFF37474F), modifier = Modifier.size(14.dp))
                        }
                    }
                    Box(Modifier.weight(0.5f).height(16.dp)) {
                        Divider(
                            color = Color(0xFFDDDDDD),
                            modifier = Modifier
                                .width(1.dp)
                                .fillMaxHeight()
                                .align(Alignment.Center)
                        )
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(Modifier.weight(1.2f).fillMaxWidth()) {
                            Box(Modifier.weight(1f))
                            Box(Modifier.weight(1f))
                            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                                Icon(Icons.Filled.LightMode, contentDescription = "Sunrise", tint = Color(0xFFF9A825), modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            Divider(color = Color(0xFFE3E7EF))

            // Body rows
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                week.forEach { d ->
                    // Today highlight (wins over default; Shabbat will still tint the divider row below)
                    val todayBg = Color(0xFFD9ECFF) // soft blue
                    val shabbatBg = Color(0xFFE8F1FF)
                    val rowBg = when {
                        d.isToday -> todayBg
                        d.isShabbat -> shabbatBg
                        else -> Color.White
                    }

                    val base = MaterialTheme.typography.bodyLarge
                    val smallHeb = base.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = (base.fontSize.value * 0.61f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )
                    val bodyLarge10 = base.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = (base.fontSize.value * 0.9f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )
                    val label10 = MaterialTheme.typography.labelSmall.copy(
                        fontSize = (MaterialTheme.typography.labelSmall.fontSize.value * 0.9f).sp,
                        platformStyle = PlatformTextStyle(includeFontPadding = false),
                        fontFeatureSettings = "tnum"
                    )

                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .padding(horizontal = 8.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // LEFT — Gregorian (abbr | day | sunset)
                        Row(Modifier.weight(1.2f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { Text(d.gregDayAbbrev, style = label10) }
                            Spacer(Modifier.width(2.dp))
                            Box(Modifier.weight(1f)) { Text(d.gregDayOfMonth, style = bodyLarge10) }
                            Spacer(Modifier.width(2.dp))
                            Box(Modifier.weight(1f)) { Text(d.sunset ?: "--", style = label10) }
                        }

                        // Middle — divider + Parasha (clickable on Shabbat)
                        Box(
                            modifier = Modifier
                                .weight(0.5f)
                                .height(IntrinsicSize.Min)
                        ) {
                            Divider(
                                color = Color(0xFFDDDDDD),
                                modifier = Modifier
                                    .width(1.dp)
                                    .fillMaxHeight()
                                    .align(Alignment.Center)
                            )
                            if (d.isShabbat && !d.parasha.isNullOrBlank()) {
                                val q = "פרשת השבוע ${d.parasha}"
                                val url = "https://www.youtube.com/results?search_query=" +
                                        URLEncoder.encode(q, StandardCharsets.UTF_8.toString())
                                Text(
                                    d.parasha!!,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .padding(horizontal = 4.dp)
                                        .clickable { uri.openUri(url) }
                                )
                            }
                        }

                        // RIGHT — Hebrew (name | heb day | sunrise), RTL
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Row(Modifier.weight(1.2f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) { Text(d.hebrewDayName, style = smallHeb) }
                                Spacer(Modifier.width(2.dp))
                                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) { Text(d.hebDayOfMonthHeb, style = smallHeb) }
                                Spacer(Modifier.width(2.dp))
                                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) { Text(d.sunrise ?: "--", style = label10, color = Color(0xFF444444)) }
                            }
                        }
                    }
                    Divider(color = Color(0xFFE3E7EF))
                }
            }
        }
    }
}

/** Shabbat summary aligned with table edges (unchanged sizing) */
@Composable
private fun ShabbatSummaryRow(candle: String?, havdalah: String?) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = SECTION_PAD_H),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SummaryBox(title = "צאת שבת", value = havdalah ?: "--", bg = Color(0xFFE6F0FF), modifier = Modifier.weight(1f))
            SummaryBox(title = "כניסת שבת", value = candle ?: "--", bg = Color(0xFFE6F0FF), modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun SummaryBox(title: String, value: String, bg: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = bg,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(
            Modifier.padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.titleSmall)
        }
    }
}

/** Prayer times — label right, time left; time = compact (match sunrise/sunset). */
@Composable
private fun PrayerTimesBoxes(anchor: DayRowUi, city: City, tz: ZoneId, board: BoardPreset) {
    val z = ZmanimProvider.computeAll(anchor.localDate, city.lat, city.lon, tz, city.elevationMeters)
    val isMGA = board == BoardPreset.MGA
    val isGRA = board == BoardPreset.GRA

    val timeStyle = MaterialTheme.typography.labelSmall.copy(
        platformStyle = PlatformTextStyle(includeFontPadding = false),
        fontFeatureSettings = "tnum"
    )

    @Composable
    fun BoxItem(label: String, time: LocalTime?, emphasize: Boolean = false) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            tonalElevation = if (emphasize) 1.dp else 0.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 46.dp)
        ) {
            // RTL container; we split space so label hugs right, time hugs left
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // LEFT (visually): time
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        Text(time?.format(HHMM) ?: "--", style = timeStyle)
                    }
                    // RIGHT (visually): label
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(Modifier.fillMaxWidth().padding(horizontal = SECTION_PAD_H)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("עלות השחר", z.alosHashachar) }
                Column(Modifier.weight(1f)) { BoxItem("זריחה", z.sunriseSeaLevel) }
                Column(Modifier.weight(1f)) { BoxItem("טלית ותפילין", z.misheyakir11_5) }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("חצות היום", z.chatzot) }
                Column(Modifier.weight(1f)) { BoxItem("מנחה גדולה", z.minchaGedola) }
                Column(Modifier.weight(1f)) { BoxItem("מנחה קטנה", z.minchaKetana) }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("פלג המנחה", z.plagHamincha) }
                Column(Modifier.weight(1f)) { BoxItem("שקיעה", z.sunsetSeaLevel) }
                Column(Modifier.weight(1f)) { BoxItem("צאת הכוכבים", z.tzeitStandard) }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז ק\"ש מג\"א", z.sofZmanShmaMGA, emphasize = isMGA) }
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז ק\"ש גרא", z.sofZmanShmaGRA, emphasize = isGRA) }
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז תפילה מג\"א", z.sofZmanTfilaMGA, emphasize = isMGA) }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז תפילה גרא", z.sofZmanTfilaGRA, emphasize = isGRA) }
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

/* Helpers */

private fun hebDayNameShort(d: LocalDate): String = when (d.dayOfWeek) {
    DayOfWeek.SUNDAY -> "ראשון"
    DayOfWeek.MONDAY -> "שני"
    DayOfWeek.TUESDAY -> "שלישי"
    DayOfWeek.WEDNESDAY -> "רביעי"
    DayOfWeek.THURSDAY -> "חמישי"
    DayOfWeek.FRIDAY -> "שישי"
    DayOfWeek.SATURDAY -> "שבת"
}

private fun hebrewMonthYear(d: LocalDate): String =
    hebrewDateFor(d, inIsrael = true).split(' ').takeLast(2).joinToString(" ")

private fun gregorianMonthSpan(start: LocalDate, end: LocalDate): String {
    val fmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)
    val a = start.withDayOfMonth(1).format(fmt)
    val b = end.withDayOfMonth(1).format(fmt)
    return if (a == b) a else "$a – $b"
}

private fun hebDayOfMonthHeb(date: LocalDate, inIsrael: Boolean = true): String {
    val cal: Calendar = GregorianCalendar().apply {
        set(Calendar.YEAR, date.year)
        set(Calendar.MONTH, date.monthValue - 1)
        set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.formatHebrewNumber(jc.jewishDayOfMonth)
}

/** Parasha for a specific Gregorian date (Hebrew name if Shabbat; else null). */
/** Parasha for a specific Gregorian date (Hebrew name if Shabbat; else null).
 *  Uses HebrewDateFormatter to avoid relying on version-specific parsha/parshaIndex APIs.
 */
private fun parashaFor(date: LocalDate, inIsrael: Boolean = true): String? {
    // Only show on Shabbat (Saturday)
    if (date.dayOfWeek != DayOfWeek.SATURDAY) return null

    val cal: Calendar = GregorianCalendar().apply {
        set(Calendar.YEAR, date.year)
        set(Calendar.MONTH, date.monthValue - 1) // 0-based
        set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
        // midday avoids DST/edge effects
        set(Calendar.HOUR_OF_DAY, 12)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    val jc = JewishCalendar().apply {
        this.inIsrael = inIsrael
        setDate(cal)
    }

    val fmt = HebrewDateFormatter().apply {
        isHebrewFormat = true
        isUseGershGershayim = true
    }

    val name = fmt.formatParsha(jc) ?: return null
    return if (name.isBlank()) null else name
}




private fun computeOccasion(d: LocalDate): String? = null // superseded by parashaFor()
