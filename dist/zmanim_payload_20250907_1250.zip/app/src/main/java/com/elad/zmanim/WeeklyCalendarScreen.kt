package com.elad.zmanim

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import com.kosherjava.zmanim.hebrewcalendar.HebrewDateFormatter
import com.kosherjava.zmanim.hebrewcalendar.JewishCalendar
import java.util.Calendar
import java.util.GregorianCalendar

data class DayRowUi(
    val localDate: LocalDate,
    val hebrewDayName: String,      // ראשון, שני, ...
    val hebDayOfMonthHeb: String,   // ז, ט״ו, כ״ט
    val gregDayAbbrev: String,      // Sun.
    val gregDayOfMonth: String,     // 31
    val sunrise: String?,           // 06:26
    val sunset: String?,            // 19:06
    val occasion: String?,
    val isShabbat: Boolean
)

private val HHMM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val GREG_DAY_ABBR: DateTimeFormatter = DateTimeFormatter.ofPattern("E", Locale.ENGLISH)
private val GREG_DAY_NUM: DateTimeFormatter = DateTimeFormatter.ofPattern("d")

@Composable
fun WeeklyCalendarScreen(
    baseDate: LocalDate,
    city: City,
    tz: ZoneId,
    board: BoardPreset,
    candleOffsetMinutes: Int?,
    modifier: Modifier = Modifier
) {
    val candleOffset = candleOffsetMinutes ?: city.defaultCandleOffsetMin

    val week: List<DayRowUi> = remember(baseDate, city, tz) {
        (0..6).map { plus ->
            val d = baseDate.plusDays(plus.toLong())
            val z = ZmanimProvider.computeAll(d, city.lat, city.lon, tz, city.elevationMeters)
            DayRowUi(
                localDate = d,
                hebrewDayName = hebDayNameShort(d),
                hebDayOfMonthHeb = hebDayOfMonthHeb(d),
                gregDayAbbrev = d.format(GREG_DAY_ABBR) + ".",
                gregDayOfMonth = d.format(GREG_DAY_NUM),
                sunrise = z.sunriseSeaLevel?.format(HHMM),
                sunset = z.sunsetSeaLevel?.format(HHMM),
                occasion = computeOccasion(d),
                isShabbat = d.dayOfWeek == DayOfWeek.SATURDAY
            )
        }
    }

    val gregSpan = remember(week) { gregorianMonthSpan(week.first().localDate, week.last().localDate) }
    val hebMonthYear = remember(baseDate) { hebrewMonthYear(baseDate) }

    val shabbatDate = remember(baseDate) { nextShabbat(baseDate) }
    val shabbatZ = remember(shabbatDate, city, tz) {
        ZmanimProvider.computeAll(shabbatDate, city.lat, city.lon, tz, city.elevationMeters)
    }

    val bgGrad = Brush.verticalGradient(listOf(Color(0xFFF3F6FB), Color(0xFFEFF3F9)))

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(bgGrad)
                .padding(horizontal = 8.dp, vertical = 6.dp) // stretch content area (smaller padding)
                .verticalScroll(rememberScrollState())
        ) {
            HeaderAndTable(
                hebMonthYear = hebMonthYear,
                cityName = city.display,
                gregSpan = gregSpan,
                week = week
            )

            Spacer(Modifier.height(8.dp))

            // Shabbat summary: candle on RIGHT, havdalah on LEFT (forced LTR order)
            ShabbatSummaryRow(
                candle = shabbatZ.sunsetSeaLevel
                    ?.minusMinutes((18 + candleOffset).toLong())
                    ?.format(HHMM),
                havdalah = shabbatZ.tzeitStandard?.format(HHMM)
            )

            Spacer(Modifier.height(10.dp))

            PrayerTimesBoxes(anchor = week.first(), city = city, tz = tz, board = board)
        }
    }
}

/** Combined header + weekly table */
@Composable
private fun HeaderAndTable(
    hebMonthYear: String,
    cityName: String,
    gregSpan: String,
    week: List<DayRowUi>
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White)
        ) {
            // Header — city larger, months smaller (−20% approx by using smaller styles)
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    gregSpan,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                )
                Text(
                    cityName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    textAlign = TextAlign.Center
                )
                Text(hebMonthYear, style = MaterialTheme.typography.labelSmall)
            }

            Divider(color = Color(0xFFECECEC))

            // Force LTR for stable "right / middle / left" ordering regardless of RTL
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                week.forEach { d ->
                    val rowBg = if (d.isShabbat) Color(0xFFE8F1FF) else Color.White
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // RIGHT (Hebrew trio) — we place it FIRST but align content to end
                        Row(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Sunrise (smaller)
                            Text(
                                d.sunrise ?: "--",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF444444)
                            )
                            Text(
                                d.hebDayOfMonthHeb,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                d.hebrewDayName,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }

                        // MIDDLE spacer + thin separator + occasion
                        Box(
                            modifier = Modifier
                                .weight(0.5f)
                                .height(IntrinsicSize.Min)
                        ) {
                            Divider(
                                color = Color(0xFFDDDDDD),
                                modifier = Modifier
                                    .width(1.dp)
                                    .fillMaxHeight()
                                    .align(Alignment.Center)
                            )
                            if (!d.occasion.isNullOrBlank()) {
                                Text(
                                    d.occasion!!,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .padding(horizontal = 4.dp)
                                )
                            }
                        }

                        // LEFT (Gregorian trio): <Sun.> <31> <19:06> with sunset horizontal
                        Row(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(d.gregDayAbbrev, style = MaterialTheme.typography.labelSmall)
                            Text(
                                d.gregDayOfMonth,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.DarkMode,
                                    contentDescription = "Sunset",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(d.sunset ?: "--", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Divider(color = Color(0xFFECECEC))
                }
            }
        }
    }
}

/** Shabbat summary: right = כניסת שבת, left = צאת שבת (forced order) */
@Composable
private fun ShabbatSummaryRow(candle: String?, havdalah: String?) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // LEFT box (havdalah)
            SummaryBox(
                title = "צאת שבת",
                value = havdalah ?: "--",
                bg = Color(0xFFE6F0FF),
                modifier = Modifier.weight(1f)
            )
            // RIGHT box (candle)
            SummaryBox(
                title = "כניסת שבת",
                value = candle ?: "--",
                bg = Color(0xFFE6F0FF),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SummaryBox(title: String, value: String, bg: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = bg,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(
            Modifier.padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

/** Prayer times in neat boxes (3 per row, slightly smaller fonts) */
@Composable
private fun PrayerTimesBoxes(anchor: DayRowUi, city: City, tz: ZoneId, board: BoardPreset) {
    val z = ZmanimProvider.computeAll(anchor.localDate, city.lat, city.lon, tz, city.elevationMeters)
    val isMGA = board == BoardPreset.MGA
    val isGRA = board == BoardPreset.GRA

    @Composable
    fun BoxItem(label: String, time: LocalTime?, emphasize: Boolean = false) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            tonalElevation = if (emphasize) 3.dp else 1.dp,
            color = if (emphasize) Color(0xFFF1F6FF) else MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(time?.format(HHMM) ?: "--", style = MaterialTheme.typography.labelLarge)
                Text(label, style = MaterialTheme.typography.labelMedium)
            }
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) { BoxItem("עלות השחר", z.alosHashachar) }
            Column(Modifier.weight(1f)) { BoxItem("טלית ותפילין", z.misheyakir11_5) }
            Column(Modifier.weight(1f)) { BoxItem("זריחה", z.sunriseSeaLevel) }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) { BoxItem("חצות היום", z.chatzot) }
            Column(Modifier.weight(1f)) { BoxItem("מנחה גדולה", z.minchaGedola) }
            Column(Modifier.weight(1f)) { BoxItem("מנחה קטנה", z.minchaKetana) }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) { BoxItem("פלג המנחה", z.plagHamincha) }
            Column(Modifier.weight(1f)) { BoxItem("שקיעה", z.sunsetSeaLevel) }
            Column(Modifier.weight(1f)) { BoxItem("צאת הכוכבים", z.tzeitStandard) }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                BoxItem("סו\"ז ק\"ש מג\"א", z.sofZmanShmaMGA, emphasize = isMGA)
                Spacer(Modifier.height(6.dp))
                BoxItem("סו\"ז תפילה מג\"א", z.sofZmanTfilaMGA, emphasize = isMGA)
            }
            Column(Modifier.weight(1f)) {
                BoxItem("סו\"ז ק\"ש גרא", z.sofZmanShmaGRA, emphasize = isGRA)
                Spacer(Modifier.height(6.dp))
                BoxItem("סו\"ז תפילה גרא", z.sofZmanTfilaGRA, emphasize = isGRA)
            }
        }
    }
}

/* Helpers */

private fun hebDayNameShort(d: LocalDate): String = when (d.dayOfWeek) {
    DayOfWeek.SUNDAY -> "ראשון"
    DayOfWeek.MONDAY -> "שני"
    DayOfWeek.TUESDAY -> "שלישי"
    DayOfWeek.WEDNESDAY -> "רביעי"
    DayOfWeek.THURSDAY -> "חמישי"
    DayOfWeek.FRIDAY -> "שישי"
    DayOfWeek.SATURDAY -> "שבת"
}

private fun hebrewMonthYear(d: LocalDate): String =
    hebrewDateFor(d, inIsrael = true).split(' ').takeLast(2).joinToString(" ")

private fun gregorianMonthSpan(start: LocalDate, end: LocalDate): String {
    val fmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)
    val a = start.withDayOfMonth(1).format(fmt)
    val b = end.withDayOfMonth(1).format(fmt)
    return if (a == b) a else "$a – $b"
}

private fun hebDayOfMonthHeb(date: LocalDate, inIsrael: Boolean = true): String {
    val cal: Calendar = GregorianCalendar().apply {
        set(Calendar.YEAR, date.year)
        set(Calendar.MONTH, date.monthValue - 1)
        set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.formatHebrewNumber(jc.jewishDayOfMonth)
}

private fun computeOccasion(d: LocalDate): String? =
    if (d.dayOfWeek == DayOfWeek.SATURDAY) "פרשת השבוע" else null
