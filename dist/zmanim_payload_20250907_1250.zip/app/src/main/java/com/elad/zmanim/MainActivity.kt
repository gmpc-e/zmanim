package com.elad.zmanim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZmanimApp() }
    }
}

private val HHMM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalAnimationApi::class)
@Composable
fun ZmanimApp() {
    var offset by remember { mutableStateOf(0) }
    var selectedCity by remember { mutableStateOf(Cities.all.first()) }
    var settings by remember { mutableStateOf(AppSettings(board = BoardPreset.GRA)) }
    var showAbout by remember { mutableStateOf(false) }

    val tz = ZoneId.of(selectedCity.tzid)
    val date = LocalDate.now(tz).plusDays(offset.toLong())

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF0D47A1), Color(0xFF1976D2), Color(0xFF42A5F5)),
        startY = 0f, endY = 1200f
    )

    // Optional: external data retained for future use
    var shabbat by remember { mutableStateOf<ShabbatSummary?>(null) }
    LaunchedEffect(selectedCity, settings.candleOffsetMinutes) {
        shabbat = ShabbatRepository.fetchUpcoming(selectedCity, tz, settings.candleOffsetMinutes)
    }
    val nextShabbatDate = remember(tz) { nextShabbat(LocalDate.now(tz)) }
    val rt72FromZmanim: ZonedDateTime? = remember(selectedCity, nextShabbatDate) {
        runCatching {
            val r = ZmanimProvider.computeAll(nextShabbatDate, selectedCity.lat, selectedCity.lon, tz)
            r.tzeitRT72?.atDate(nextShabbatDate)?.atZone(tz)
        }.getOrNull()
    }

    // Stretch to screen edges a bit more (padding ↓ from 12dp → 6dp)
    Box(
        Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(6.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(16.dp), // slightly tighter corners for more space
            tonalElevation = 6.dp,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
        ) {
            AnimatedContent(
                targetState = Triple(date, selectedCity, settings.board),
                transitionSpec = {
                    (fadeIn(animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy)) togetherWith
                            fadeOut(animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy)))
                },
                label = "date-city-board"
            ) { (d, city, board) ->
                Column(Modifier.fillMaxSize().padding(8.dp)) {

                    // Controls: City (left), Board (right) + small "i" near Board
                    ControlsBox(
                        city = city,
                        onCityChange = { selectedCity = it },
                        board = board,
                        onBoardChange = { settings = settings.copy(board = it) },
                        onInfo = { showAbout = true }
                    )

                    Spacer(Modifier.height(8.dp))

                    WeeklyCalendarScreen(
                        baseDate = d,
                        city = city,
                        tz = tz,
                        board = board,
                        candleOffsetMinutes = settings.candleOffsetMinutes,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    if (showAbout) {
        AboutDialog(onDismiss = { showAbout = false })
    }
}

/** Controls row: Board selector (right, with an info icon), City (left). */
@Composable
fun ControlsBox(
    city: City,
    onCityChange: (City) -> Unit,
    board: BoardPreset,
    onBoardChange: (BoardPreset) -> Unit,
    onInfo: () -> Unit
) {
    Surface(tonalElevation = 1.dp, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .padding(horizontal = 10.dp, vertical = 4.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // LEFT
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                CityDropdown(city = city, onCityChange = onCityChange)
            }
            Spacer(Modifier.width(12.dp))
            // RIGHT (Board + small "i" at its top-left)
            Box(Modifier.weight(1f)) {
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = onInfo,
                        modifier = Modifier.size(24.dp) // small “i”
                    ) {
                        Icon(Icons.Outlined.Info, contentDescription = "About Zmanim methods")
                    }
                    BoardDropdown(board = board, onBoardChange = onBoardChange)
                }
            }
        }
    }
}
