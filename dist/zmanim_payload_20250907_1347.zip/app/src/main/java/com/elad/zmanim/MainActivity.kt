package com.elad.zmanim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZmanimApp() }
    }
}

private val HHMM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalAnimationApi::class)
@Composable
fun ZmanimApp() {
    var offset by remember { mutableStateOf(0) }
    var selectedCity by remember { mutableStateOf(Cities.all.first()) }
    var settings by remember { mutableStateOf(AppSettings(board = BoardPreset.GRA)) }
    var showAbout by remember { mutableStateOf(false) }
    var showCityPicker by remember { mutableStateOf(false) }

    val tz = ZoneId.of(selectedCity.tzid)
    val date = LocalDate.now(tz).plusDays(offset.toLong())

    val gradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF0D47A1), Color(0xFF1976D2), Color(0xFF42A5F5)),
        startY = 0f, endY = 1200f
    )

    // Optional: external data retained for future use
    var shabbat by remember { mutableStateOf<ShabbatSummary?>(null) }
    LaunchedEffect(selectedCity, settings.candleOffsetMinutes) {
        shabbat = ShabbatRepository.fetchUpcoming(selectedCity, tz, settings.candleOffsetMinutes)
    }
    val nextShabbatDate = remember(tz) { nextShabbat(LocalDate.now(tz)) }
    val rt72FromZmanim: ZonedDateTime? = remember(selectedCity, nextShabbatDate) {
        runCatching {
            val r = ZmanimProvider.computeAll(nextShabbatDate, selectedCity.lat, selectedCity.lon, tz)
            r.tzeitRT72?.atDate(nextShabbatDate)?.atZone(tz)
        }.getOrNull()
    }

    // Reduce overall chrome: tighter padding/radius/elevation to avoid overlap near watch icons
    Box(
        Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(4.dp) // was 6dp
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(12.dp), // was 16dp
            tonalElevation = 4.dp,             // was 6dp
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
        ) {
            AnimatedContent(
                targetState = Triple(date, selectedCity, settings.board),
                transitionSpec = {
                    (fadeIn(animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy)) togetherWith
                            fadeOut(animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy)))
                },
                label = "date-city-board"
            ) { (d, city, board) ->
                Column(Modifier.fillMaxSize().padding(6.dp)) { // was 8dp
                    // New compact header (no City dropdown here)
                    ZmanimHeader(
                        board = board,
                        onBoardChange = { settings = settings.copy(board = it) },
                        onInfo = { showAbout = true }
                    )

                    Spacer(Modifier.height(6.dp)) // was 8dp

                    WeeklyCalendarScreen(
                        baseDate = d,
                        city = city,
                        tz = tz,
                        board = board,
                        candleOffsetMinutes = settings.candleOffsetMinutes,
                        onCityClick = { showCityPicker = true }, // ← click city title to change city
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    if (showAbout) {
        AboutDialog(onDismiss = { showAbout = false })
    }

    if (showCityPicker) {
        CityPickerDialog(
            current = selectedCity,
            onPick = { selectedCity = it; showCityPicker = false },
            onDismiss = { showCityPicker = false }
        )
    }
}

/** New compact header: app title + board line (dropdown) + info icon */
@Composable
fun ZmanimHeader(
    board: BoardPreset,
    onBoardChange: (BoardPreset) -> Unit,
    onInfo: () -> Unit
) {
    Surface(
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp) // tighter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp), // tighter
            horizontalAlignment = Alignment.End
        ) {
            // Line 1: App name
            Text(
                "זמנים - לוח שנה יהודי",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
            )

            Spacer(Modifier.height(2.dp))

            // Line 2: "<board_name>  ע״פ שיטת" + small "i"
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IconButton(
                    onClick = onInfo,
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(Icons.Outlined.Info, contentDescription = "About Zmanim methods")
                }
                // The board name is interactive (opens dropdown)
                BoardDropdown(
                    board = board,
                    onBoardChange = onBoardChange
                )
                Text(
                    "ע״פ שיטת",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                )
            }
        }
    }
}

/** Simple city picker dialog that reuses Cities.all */
@Composable
fun CityPickerDialog(
    current: City,
    onPick: (City) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("סגור") } },
        title = { Text("בחר עיר") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Cities.all.forEach { c ->
                    Text(
                        text = if (c == current) "• ${c.display}" else c.display,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(c) }
                            .padding(vertical = 8.dp)
                    )
                }
            }
        }
    )
}
