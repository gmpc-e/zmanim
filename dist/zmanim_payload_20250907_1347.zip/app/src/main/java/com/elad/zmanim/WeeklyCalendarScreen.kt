package com.elad.zmanim

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import com.kosherjava.zmanim.hebrewcalendar.HebrewDateFormatter
import com.kosherjava.zmanim.hebrewcalendar.JewishCalendar
import java.util.Calendar
import java.util.GregorianCalendar

data class DayRowUi(
    val localDate: LocalDate,
    val hebrewDayName: String,
    val hebDayOfMonthHeb: String,
    val gregDayAbbrev: String,
    val gregDayOfMonth: String,
    val sunrise: String?,
    val sunset: String?,
    val occasion: String?,
    val isShabbat: Boolean
)

private val HHMM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")
private val GREG_DAY_ABBR: DateTimeFormatter = DateTimeFormatter.ofPattern("E", Locale.ENGLISH)
private val GREG_DAY_NUM: DateTimeFormatter = DateTimeFormatter.ofPattern("d")

@Composable
fun WeeklyCalendarScreen(
    baseDate: LocalDate,
    city: City,
    tz: ZoneId,
    board: BoardPreset,
    candleOffsetMinutes: Int?,
    modifier: Modifier = Modifier,
    onCityClick: () -> Unit = {} // NEW: clicking city title opens city picker
) {
    val candleOffset = candleOffsetMinutes ?: city.defaultCandleOffsetMin

    val week: List<DayRowUi> = remember(baseDate, city, tz) {
        (0..6).map { plus ->
            val d = baseDate.plusDays(plus.toLong())
            val z = ZmanimProvider.computeAll(d, city.lat, city.lon, tz, city.elevationMeters)
            DayRowUi(
                localDate = d,
                hebrewDayName = hebDayNameShort(d),
                hebDayOfMonthHeb = hebDayOfMonthHeb(d),
                gregDayAbbrev = d.format(GREG_DAY_ABBR) + ".",
                gregDayOfMonth = d.format(GREG_DAY_NUM),
                sunrise = z.sunriseSeaLevel?.format(HHMM),
                sunset = z.sunsetSeaLevel?.format(HHMM),
                occasion = computeOccasion(d),
                isShabbat = d.dayOfWeek == DayOfWeek.SATURDAY
            )
        }
    }

    val gregSpan = remember(week) { gregorianMonthSpan(week.first().localDate, week.last().localDate) }
    val hebMonthYear = remember(baseDate) { hebrewMonthYear(baseDate) }

    val shabbatDate = remember(baseDate) { nextShabbat(baseDate) }
    val shabbatZ = remember(shabbatDate, city, tz) {
        ZmanimProvider.computeAll(shabbatDate, city.lat, city.lon, tz, city.elevationMeters)
    }

    val bgGrad = Brush.verticalGradient(listOf(Color(0xFFF5F7FC), Color(0xFFF0F4FA))) // slightly lighter

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .background(bgGrad)
                .padding(horizontal = 6.dp, vertical = 4.dp) // tighter than before
                .verticalScroll(rememberScrollState())
        ) {
            HeaderAndTable(
                hebMonthYear = hebMonthYear,
                cityName = city.display,
                gregSpan = gregSpan,
                week = week,
                onCityClick = onCityClick
            )

            Spacer(Modifier.height(6.dp))

            // Shabbat summary
            ShabbatSummaryRow(
                candle = shabbatZ.sunsetSeaLevel
                    ?.minusMinutes((18 + candleOffset).toLong())
                    ?.format(HHMM),
                havdalah = shabbatZ.tzeitStandard?.format(HHMM)
            )

            Spacer(Modifier.height(8.dp))

            PrayerTimesBoxes(anchor = week.first(), city = city, tz = tz, board = board)
        }
    }
}

/** Combined header + weekly table */
@Composable
private fun HeaderAndTable(
    hebMonthYear: String,
    cityName: String,
    gregSpan: String,
    week: List<DayRowUi>,
    onCityClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp), // was 14dp
        tonalElevation = 1.dp,             // was 2dp
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White)
        ) {
            // Header — city emphasized, smaller months; city is clickable now
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp), // smaller
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    gregSpan,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                )
                Text(
                    cityName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.clickable { onCityClick() } // ← click to change city
                )
                Text(hebMonthYear, style = MaterialTheme.typography.labelSmall)
            }

            Divider(color = Color(0xFFE3E7EF))

            // Force LTR so visual order is: [Gregorian] | [Middle] | [Hebrew]
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                week.forEach { d ->
                    val rowBg = if (d.isShabbat) Color(0xFFE8F1FF) else Color.White
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(rowBg)
                            .padding(horizontal = 8.dp, vertical = 5.dp), // tighter
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // LEFT CELL — Gregorian trio (<Sun.> <31> <19:06>)
                        Row(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Text(d.gregDayAbbrev, style = MaterialTheme.typography.labelSmall)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                d.gregDayOfMonth,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Spacer(Modifier.width(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.DarkMode,
                                    contentDescription = "Sunset",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(d.sunset ?: "--", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // MIDDLE — thin separator + optional occasion
                        Box(
                            modifier = Modifier
                                .weight(0.5f)
                                .height(IntrinsicSize.Min)
                        ) {
                            Divider(
                                color = Color(0xFFDDDDDD),
                                modifier = Modifier
                                    .width(1.dp)
                                    .fillMaxHeight()
                                    .align(Alignment.Center)
                            )
                            if (!d.occasion.isNullOrBlank()) {
                                Text(
                                    d.occasion!!,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .padding(horizontal = 4.dp)
                                )
                            }
                        }

                        // RIGHT CELL — Hebrew trio (right→left): hebrewDayName (−25%), hebDayOfMonthHeb (−25%), sunrise
                        Row(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                val base = MaterialTheme.typography.bodyLarge
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Start // RTL: Start == right edge
                                ) {
                                    Text(
                                        d.hebrewDayName,
                                        style = base.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = base.fontSize * 0.75f
                                        )
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        d.hebDayOfMonthHeb,
                                        style = base.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = base.fontSize * 0.75f
                                        )
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        d.sunrise ?: "--",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF444444)
                                    )
                                }
                            }
                        }
                    }
                    Divider(color = Color(0xFFE3E7EF))
                }
            }
        }
    }
}

/** Shabbat summary: right = כניסת שבת, left = צאת שבת (forced order) */
@Composable
private fun ShabbatSummaryRow(candle: String?, havdalah: String?) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp) // tighter
        ) {
            SummaryBox(
                title = "צאת שבת",
                value = havdalah ?: "--",
                bg = Color(0xFFE6F0FF),
                modifier = Modifier.weight(1f)
            )
            SummaryBox(
                title = "כניסת שבת",
                value = candle ?: "--",
                bg = Color(0xFFE6F0FF),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SummaryBox(title: String, value: String, bg: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp), // slightly smaller
        color = bg,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(
            Modifier.padding(vertical = 10.dp), // tighter
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

/** Prayer times in neat boxes (3 per row, RTL flow per requested order 1→13) */
@Composable
private fun PrayerTimesBoxes(anchor: DayRowUi, city: City, tz: ZoneId, board: BoardPreset) {
    val z = ZmanimProvider.computeAll(anchor.localDate, city.lat, city.lon, tz, city.elevationMeters)
    val isMGA = board == BoardPreset.MGA
    val isGRA = board == BoardPreset.GRA

    @Composable
    fun BoxItem(label: String, time: LocalTime?, emphasize: Boolean = false) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            tonalElevation = if (emphasize) 2.dp else 1.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 60.dp) // a hair smaller, still safe
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    time?.format(HHMM) ?: "--",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }

    // Lay out RIGHT→LEFT visually with the provided order 1..13
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(Modifier.fillMaxWidth()) {
            // Row 1: 1,2,3
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("עלות השחר", z.alosHashachar) }     // 1
                Column(Modifier.weight(1f)) { BoxItem("זריחה", z.sunriseSeaLevel) }       // 2
                Column(Modifier.weight(1f)) { BoxItem("טלית ותפילין", z.misheyakir11_5) } // 3
            }
            Spacer(Modifier.height(6.dp))

            // Row 2: 4,5,6
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("חצות היום", z.chatzot) }         // 4
                Column(Modifier.weight(1f)) { BoxItem("מנחה גדולה", z.minchaGedola) }   // 5
                Column(Modifier.weight(1f)) { BoxItem("מנחה קטנה", z.minchaKetana) }    // 6
            }
            Spacer(Modifier.height(6.dp))

            // Row 3: 7,8,9
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("פלג המנחה", z.plagHamincha) }    // 7
                Column(Modifier.weight(1f)) { BoxItem("שקיעה", z.sunsetSeaLevel) }      // 8
                Column(Modifier.weight(1f)) { BoxItem("צאת הכוכבים", z.tzeitStandard) } // 9
            }
            Spacer(Modifier.height(6.dp))

            // Row 4: 10,11,12
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז ק\"ש מג\"א", z.sofZmanShmaMGA, emphasize = isMGA) } // 10
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז ק\"ש גרא", z.sofZmanShmaGRA, emphasize = isGRA) }   // 11
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז תפילה מג\"א", z.sofZmanTfilaMGA, emphasize = isMGA) } // 12
            }
            Spacer(Modifier.height(6.dp))

            // Row 5: 13 (single), keep grid rhythm with 2 spacers
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) { BoxItem("סו\"ז תפילה גרא", z.sofZmanTfilaGRA, emphasize = isGRA) } // 13
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

/* Helpers */

private fun hebDayNameShort(d: LocalDate): String = when (d.dayOfWeek) {
    DayOfWeek.SUNDAY -> "ראשון"
    DayOfWeek.MONDAY -> "שני"
    DayOfWeek.TUESDAY -> "שלישי"
    DayOfWeek.WEDNESDAY -> "רביעי"
    DayOfWeek.THURSDAY -> "חמישי"
    DayOfWeek.FRIDAY -> "שישי"
    DayOfWeek.SATURDAY -> "שבת"
}

private fun hebrewMonthYear(d: LocalDate): String =
    hebrewDateFor(d, inIsrael = true).split(' ').takeLast(2).joinToString(" ")

private fun gregorianMonthSpan(start: LocalDate, end: LocalDate): String {
    val fmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)
    val a = start.withDayOfMonth(1).format(fmt)
    val b = end.withDayOfMonth(1).format(fmt)
    return if (a == b) a else "$a – $b"
}

private fun hebDayOfMonthHeb(date: LocalDate, inIsrael: Boolean = true): String {
    val cal: Calendar = GregorianCalendar().apply {
        set(Calendar.YEAR, date.year)
        set(Calendar.MONTH, date.monthValue - 1)
        set(Calendar.DAY_OF_MONTH, date.dayOfMonth)
    }
    val jc = JewishCalendar().apply { this.inIsrael = inIsrael; setDate(cal) }
    val fmt = HebrewDateFormatter().apply { isHebrewFormat = true; isUseGershGershayim = true }
    return fmt.formatHebrewNumber(jc.jewishDayOfMonth)
}

private fun computeOccasion(d: LocalDate): String? =
    if (d.dayOfWeek == DayOfWeek.SATURDAY) "פרשת השבוע" else null
